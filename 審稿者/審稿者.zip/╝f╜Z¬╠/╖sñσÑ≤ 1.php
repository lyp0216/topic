<?php 

function manuscriptnumber()
{                           $host = 'localhost';
                            $dbuser ='root';
                            $dbpassword = '';
                            $dbname = '審稿者';
                            $link = mysqli_connect($host,$dbuser,$dbpassword,$dbname);
							$sql = "SELECT 稿件編號 FROM 待評閱" ;					
}	

echo manuscriptnumber(); 

?>

$result = mysqli_query($link, $sql);
							echo"<table border=1><tr>";
							while ( $meta = mysqli_fetch_field($result) )
								echo "<td>".$meta->name."</td>"
							echo"</tr>"
							$total_fields = mysqli_