<?php
header("Content-type:application");
header("Content-Disposition: attachment; filename=file_name");
//file_name是預設下載時的檔名，可使用變數。
readfile("file");
//file是實際存放在你硬碟中要被下載的檔案，可使用變數。
exit(0);

header('Content-Type: application/pdf');
header('Content-Disposition: attachment; filename="downloaded.pdf"');
readfile('original.pdf');
//限制下載速度，使用 while 迴圈加上 sleep。

while (!feof($handle)) {
echo fread($handle, 8192);
sleep(1);
}

$content = "";
$fp = fopen("http://file-to-download.com/a-file.zip", "rb");

if (!$fp)
die("Error opening file.");
while (!feof($fp))
$content .= fread($fp, 2048);
fclose($fp);

$fp=fopen("local-file-name.zip", "w");
fwrite($fp, $content);
fclose($fp);

$OrgFileName = mb_convert_encoding($OrgFileName, 'BIG-5','UTF-8');

$real_path = dirname(__FILE__).'/upload/'.$FileName;

header('Pragma: public');

header('Expires: 0');

header('Cache-Control: must-revalidate, post-check=0, pre-check=0');

header('Cache-Control: public', false);

header('Content-Description: File Transfer');

header('Accept-Ranges: bytes');

// application/force-download 為通用類型，亦可判斷檔案格式做改變

header('Content-Type: application/force-download');

header('Content-Length: '.filesize($real_path));

header('Content-Transfer-Encoding: binary');

// 注意「"」不可省略，否則FireFox會無法正確讀取

header('Content-Disposition:attachment;filename="'.$OrgFileName.'"');

// 讀取來源檔案資料

if ($stream = fopen($real_path, 'rb')){

while(!feof($stream) && connection_status() == 0){

echo(fread($stream,1024*8));

flush();

}

fclose($stream);

}
?>