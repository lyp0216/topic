<!DOCTYPE html>
<html lang="en">

<?php

                            $host = 'localhost';
                            $dbuser ='root';
                            $dbpassword = '';
                            $dbname = '審稿者';
                            $link = mysqli_connect($host,$dbuser,$dbpassword,$dbname);
						    $sql = "SELECT * FROM 待評閱" ;
                            $result = mysqli_query($link, $sql);							

?>

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="./css/header.css">
	<link rel="stylesheet" href="./css/container2.css">
	<link rel="stylesheet" href="./css/container.css">
	<link rel="stylesheet" href="css/footer.css">
	<link rel="stylesheet" href="./css/reader.css">
	<title>請求評閱</title>
</head>
<body>

	<header>
		<div class="headerImg"><a href=""><img src="img/chihleeB.png" alt=""></a></div>
		<div class="headerNav">
			<nav>
				<ul class="flex-nav">
					<li><a href="#A">首頁</a></li>
					<li><a href="#B">關於論文</a></li>
					<li><a href="#C">投稿方式</a></li>
					<li><a href="#D">投稿專區</a></li>
					<li><a href="#D">審稿專區</a></li>
				</ul>
			</nav>
		</div>
		<div class="headerA" >
			<div class="headerIcon">
				<a href="" style="margin: 0px 90px 0px 15px;"><img src="img/settings.png" alt=""style="width: 20px;height: 20px;"></a>
				<a href="" style="margin: 0px 15px;"><img src="img/user.png" alt=""style="width: 20px;height: 20px;"></a>
			</div>
			
			
		</div>
	</header>
	<div class="container">
		<div class="reader">
			<div class="ReaderTitle">
				<ol class="breadcrumb">
  					<li class="breadcrumb-item active"><span><a href="審稿者首頁.php">所有評閱</a></span></li>
				</ol>
			</div>
			<ul class="title" style="list-style-image: square">
				<li><strong>待評閱</strong></li>
			</ul>
			<table class="tableR">
  				<tbody>
    				<tr>
      					<th scope="col">稿件編號</th>
     					<th scope="col">篇名</th>
      					<th scope="col">邀請期限</th>
      					<th scope="col">審稿期限</th>
						<th scope="col">評閱狀態</th>
						<th scope="col">姓名</th>
						<th scope="col">稿件類別</th>
						<th scope="col">作品摘要</th>
    				</tr>
					
					<?php
					$total_fields = mysqli_num_fields($result);
					
					while ($row = mysqli_fetch_row($result)){
						echo "<tr>";
						for( $i = 0;$i <= $total_fields-1; $i++ ){
						if($i==0){
								echo"<td><a href='審稿頁面請求評閱.php?id=$row[$i]'>$row[$i]</a></td>";
							continue;
							}
							
							echo "<td>" . $row[$i] . "</td>";
						}
							
						echo"</tr>";
					}
					
					?>
					
  				</tbody>
			</table>
			<ul class="pagination">
  				<li><a href="#">«</a></li>
  				<li><a href="#">1</a></li>
  				<li><a class="active" href="#">2</a></li>
  				<li><a href="#">3</a></li>
  				<li><a href="#">4</a></li>
  				<li><a href="#">5</a></li>
  				<li><a href="#">6</a></li>
  				<li><a href="#">7</a></li>
  				<li><a href="#">»</a></li>
			</ul>
		</div>
	</div>
	<footer>

		<div class="minner">
			<div class="copyright">

				<div class="bt_link">
					<ul class="bt_link_ul">
						<li><a href="https://www.chihlee.edu.tw/p/404-1000-22257.php?Lang=zh-tw"
								title="個資(隱私)保護服務及宣告">個資(隱私)保護服務及宣告</a></li>
						<li><a href="https://www.chihlee.edu.tw/p/404-1000-55575.php?Lang=zh-tw" title="個資政策">個資政策</a>
						</li>
						<li><a href="https://www.chihlee.edu.tw/p/404-1000-55576.php?Lang=zh-tw"
								title="個人資料告知聲明">個人資料告知聲明</a></li>
					</ul>
				</div>
				<div class="bt_text">
					Copyright &copy; 2022 All rights reserved.
					<br>
					220305 新北市板橋區文化路1段313號
					<br>
					No.313, Sec. 1, Wenhua Rd., Banqiao Dist., New Taipei City 220305, Taiwan (R.O.C.)
					<br>
					TEL：(02)2257-6167 │ (02)2257-6168 │ FAX：(02)2258-3710
				</div>

			</div>
		</div>
	</footer>
</body>

</html>