<!DOCTYPE html>
<html lang="en">

<?php
                            
function pendingreview()
{                           $host = 'localhost';
                            $dbuser ='root';
                            $dbpassword = '';
                            $dbname = '審稿者';
                            $link = mysqli_connect($host,$dbuser,$dbpassword,$dbname);
							$sql = "SELECT * FROM 待評閱" ;
							
							if ($result = mysqli_query($link,$sql))
							{
							$total_records = mysqli_num_rows($result);
							return  $total_records;
							}
}							
function review()
{
	                        $host = 'localhost';
                            $dbuser ='root';
                            $dbpassword = '';
                            $dbname = '審稿者';
                            $link = mysqli_connect($host,$dbuser,$dbpassword,$dbname);
							$sql = "SELECT * FROM 評閱中" ;
							
							if ($result = mysqli_query($link,$sql))
							{
							$total_records = mysqli_num_rows($result);
							return  $total_records;
							}
}
function Reviewafterrevision()
{
	                        $host = 'localhost';
                            $dbuser ='root';
                            $dbpassword = '';
                            $dbname = '審稿者';
                            $link = mysqli_connect($host,$dbuser,$dbpassword,$dbname);
							$sql = "SELECT * FROM 修改後評閱" ;
							
							if ($result = mysqli_query($link,$sql))
							{
							$total_records = mysqli_num_rows($result);
							return  $total_records;
							}
}
function completereview()
{
	                        $host = 'localhost';
                            $dbuser ='root';
                            $dbpassword = '';
                            $dbname = '審稿者';
                            $link = mysqli_connect($host,$dbuser,$dbpassword,$dbname);
							$sql = "SELECT * FROM 完成評閱" ;
							
							if ($result = mysqli_query($link,$sql))
							{
							$total_records = mysqli_num_rows($result);
							return  $total_records;
							}
}
							?>

<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<link rel="stylesheet" href="./css/header.css">
	<link rel="stylesheet" href="./css/container.css">
	<link rel="stylesheet" href="./css/container2.css">
	<link rel="stylesheet" href="css/footer.css">
	<title>所有評閱</title>
</head>

<body>



	<header>
		<div class="headerImg"><a href=""><img src="img/chihleeB.png" alt=""></a></div>
		<div class="headerNav">
			<nav>
				<ul class="flex-nav">
					<li><a href="#A">首頁</a></li>
					<li><a href="#B">關於論文</a></li>
					<li><a href="#C">投稿方式</a></li>
					<li><a href="#D">投稿專區</a></li>
					<li><a href="#D">審稿專區</a></li>
				</ul>
			</nav>
		</div>
		<div class="headerA">
			<div class="headerIcon">
				<a href="" style="margin: 0px 90px 0px 15px;"><img src="img/settings.png" alt=""
						style="width: 20px;height: 20px;"></a>
				<a href="" style="margin: 0px 15px;"><img src="img/user.png" alt=""
						style="width: 20px;height: 20px;"></a>
			</div>


		</div>
	</header>
	<div class="container">
		<div class="reader">
			<div class="ReaderTitle">
				<ol class="breadcrumb">
					<li class="breadcrumb-item active"><span><a href="審稿者首頁.php">所有評閱</a></span></li>
				</ol>
			</div>
			<div class="but">
				<div class="ReaderBut">
					<div style="display: flex;">
						<div class="bottonBox">
							<input class="btnNew btnColor b myMOUSE" type="button" name="register" value="待評閱"
								onclick="window.location.href='請求評閱.php'" />
						</div>
						<div class="numBox">
							<span>
							<?php echo pendingreview(); ?>
							</span>
						</div>
						<span style="margin: auto 0;color: #000;">篇</span><br>
					</div>
					<div style="display: flex;">
						<div class="bottonBox">
							<input class="btnNew btnColor myMOUSE" type="button" name="register" value="評閱中"
								onclick="window.location.href='評閱中.php'" />
						</div>
						<div class="numBox">
							<span><?php echo review(); ?></span>
						</div>
						<span style="margin: auto 0;color: #000;">篇</span><br>
					</div>
					<h2>歷史評閱紀錄</h2>
					<div style="display: flex;">
						<div class="bottonBox">
							<input class="btnNew btnColor  myMOUSE" type="button" name="register" value="修改後評閱"
								onclick="window.location.href='修改後評閱.php'" />
						</div>
						<div class="numBox">
							<span><?php echo Reviewafterrevision(); ?></span>
						</div>
						<span style="margin: auto 0;color: #000;">篇</span><br>
					</div>
					<div style="display: flex;">
						<div class="bottonBox">
							<input class="btnNew btnColor a  myMOUSE" type="button" name="register" value="完成評閱"
								onclick="window.location.href='完成評閱.php'" />
						</div>
						<div class="numBox">
							<span><?php echo completereview(); ?></span>
						</div>
						<span style="margin: auto 0;color: #000;">篇</span><br>
					</div>
					<!--<input class="btnNew btnColor myMOUSE" type="button" name="register" value="評閱中" onclick="window.location.href='評閱中.html'"/><span>0</span>篇<br>
				
				<input class="btnNew btnColor  myMOUSE" type="button" name="register" value="待修改評閱" onclick="window.location.href='修改後待評閱.html'"/><span>0</span>篇<br>
				<input class="btnNew btnColor a  myMOUSE" type="button" name="register" value="完成評閱" onclick="window.location.href='完成評閱.html'"/><span>0</span>篇<br>
				<input class="btnNew btnColor a myMOUSE" type="button" name="register" value="拒絕評閱" onclick="window.location.href='拒絕評閱.html'"/><span>0</span>篇-->

				</div>
			</div>
		</div>
	</div>
	<footer>

		<div class="minner">
			<div class="copyright">

				<div class="bt_link">
					<ul class="bt_link_ul">
						<li><a href="https://www.chihlee.edu.tw/p/404-1000-22257.php?Lang=zh-tw"
								title="個資(隱私)保護服務及宣告">個資(隱私)保護服務及宣告</a></li>
						<li><a href="https://www.chihlee.edu.tw/p/404-1000-55575.php?Lang=zh-tw" title="個資政策">個資政策</a>
						</li>
						<li><a href="https://www.chihlee.edu.tw/p/404-1000-55576.php?Lang=zh-tw"
								title="個人資料告知聲明">個人資料告知聲明</a></li>
					</ul>
				</div>
				<div class="bt_text">
					Copyright &copy; 2022 All rights reserved.
					<br>
					220305 新北市板橋區文化路1段313號
					<br>
					No.313, Sec. 1, Wenhua Rd., Banqiao Dist., New Taipei City 220305, Taiwan (R.O.C.)
					<br>
					TEL：(02)2257-6167 │ (02)2257-6168 │ FAX：(02)2258-3710
				</div>

			</div>
		</div>
	</footer>
	<!--<div class="footer"></div>-->

</body>

</html>