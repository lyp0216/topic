-----------------------------
					<?php
					while ($row = mysqli_fetch_row($result)){
						echo "<tr>";
						for( $i = 0;$i <=4; $i++ ){
						if($i==0){
								echo"<td><a href='審稿頁面完成評閱.php?ID=$row[$i]'>$row[$i]</a></td>";
							continue;
							}
							
							echo "<td>" . $row[$i] . "</td>";
						}
							
							while ($row = mysqli_fetch_row($result)){
      echo"<tr>";
      echo"<td><a href='審稿頁面請求評閱.php?id=$row["稿件編號"]'>$row["稿件編號"]</a></td>";
      echo"<td>" . $row["篇名"] . "</td>";
      echo"<td>" . $row["邀請期限"] . "</td>";
      echo"<td>" . $row["審稿期限"] . "</td>";
      echo"<td>" . $row["評閱狀態"] . "</td>";
      }
       
      echo"</tr>";
     }------------------------------
						echo"</tr>";
					}
					
					
					?>
					
					
                            $host = 'localhost';
                            $dbuser ='root';
                            $dbpassword = '';
                            $dbname = '審稿者';
                            $link = mysqli_connect($host,$dbuser,$dbpassword,$dbname);
							$num = $_GET['id'];
						    $sql = "SELECT * FROM 待評閱 where 稿件編號='$num'" ;
                            $result = mysqli_query($link, $sql);							
                            $row = mysqli_fetch_row($result);
							
							$total_fields = mysqli_num_fields($result);
							
							請求評閱
					while ($row = mysqli_fetch_array($result,MYSQLI_ASSOC)){
						echo "<tr>";
						
      echo"<td><a href='審稿頁面請求評閱.php?id=$row["稿件編號"]'>$row["稿件編號"]</a></td>";
      echo"<td>" . $row["篇名"] . "</td>";
      echo"<td>" . $row["邀請期限"] . "</td>";
      echo"<td>" . $row["審稿期限"] . "</td>";
      echo"<td>" . $row["評閱狀態"] . "</td>";
      }
       
      echo"</tr>";
	  
	  審稿葉面請求評閱
	  
	  $host = 'localhost';
                            $dbuser ='root';
                            $dbpassword = '';
                            $dbname = '審稿者';
                            $link = mysqli_connect($host,$dbuser,$dbpassword,$dbname);
							$num = $_GET['id'];
						    $sql = "SELECT * FROM 待評閱 where 稿件編號='$num'" ;
                            $result = mysqli_query($link, $sql);							
                            $row = mysqli_fetch_row($result);
							--------------------------------------------------------
							
<? header("Content-type: text/html; charset=utf-8");

if (empty($_SERVER['PHP_AUTH_USER'])) {

header('WWW-Authenticate: Basic realm="Please input"');

header('HTTP/1.0 401 Unauthorized');

echo '請輸入正確的帳號及密碼, 不可以取消!';

exit;

} else {

$correctName="pcschool";

$correctpwd="mysql" ;

if (($_SERVER['PHP_AUTH_USER'] != $correctName) or

($_SERVER['PHP_AUTH_PW'] !=$correctpwd)){

echo "登入失敗,請開啟新的瀏覽器重新登入";

}

}

?>